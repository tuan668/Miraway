<!doctype html>
<html lang="en">
  
  <?php include 'head.php'; ?>

  <body>

    <section id="login-form">
      <div class="container">
          <h3 class="text text-center mb-3">Đăng nhập</h3>
          <div class="modal-dialog modal-sm modal-dialog-centered">
            <form class="w-100">
              <div class="mb-3">
                <label for="exampleInputEmail" class="form-label">Email</label>
                <input type="email" class="form-control" id="exampleInputEmail" aria-describedby="email">
              </div>
              <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Mật khẩu</label>
                <input type="password" class="form-control" id="exampleInputPassword1">
              </div>
              <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
            </form>
          </div>
      </div>
    </section>

    <?php include 'footer.php'; ?>
  </body>
</html>
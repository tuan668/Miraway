<!doctype html>
<html lang="en">
  
  <?php include 'head.php'; ?>

  <body>
    <header id="header">
      <div class="container">
        <div class="menu">
          <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"><img src="../demo/img/logo.svg"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Giới thiệu</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Giải pháp</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Tin tức & sự kiện</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Cơ hội nghề nghiệp</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="login.php">Đăng nhập</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </header>

    <main>
      <div class="container">
        <section class="section-1">
          <div class="row">
            <div class="left col-sm-8 mb-3 mb-sm-0">
              <div class="card">
                <img src="../demo/img/image-90.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">DATA – TRÁI TIM CỦA CÔNG NGHỆ CHUYỂN ĐỔI SỐ</h5>
                  <p class="card-text">Chuyển đổi công nghệ số đang trở thành xu hướng không thể tránh khỏi đối với các doanh nghiệp trong thời đại ngày nay. Với sự phát triển của 4.0 thì chuyển đổi số đã không còn là sự lựa chọn mà là con đường bắt buộc của những doanh nghiệp muốn thành công. Vậy phải làm thế nào? Dựa trên cái gì? Hãy cùng Miraway tìm hiểu</p>
                  <div class="button">
                    <a href="#" class="date">_ 07/07/2023_ Phạm Uyên_ 0 Comments</a>
                    <a href="#" class="read-more float-end">Xem thêm</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="right col-sm-4">
              <div class="card mb-3">
                <img src="../demo/img/image-92.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Ứng dụng CDP phân tích nguyện vọng và hành vi của khách hàng lĩnh vực tài chính ngân hàng</h5>
                  <div class="button">
                    <a href="#" class="date">_ 07/07/2023_</a>
                    <a href="#" class="read-more float-end">Xem thêm</a>
                  </div>
                </div>
              </div>
              <div class="card">
                <img src="../demo/img/image-93.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Miraway tài trợ hội thảo IDG – Chuyển đổi số trong lĩnh vực Tài chính – Ngân hàng và Fintech – Dữ liệu cá nhân</h5>
                  <div class="button">
                    <a href="#" class="date">_ 07/07/2023_</a>
                    <a href="#" class="read-more float-end">Xem thêm</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="section-2 pt-5 pb-5">
          <div class="row">
            <h1 class="text d-flex justify-content-center">Miraway trên mạng xã hội</h1>
            <div class="d-flex d-inline justify-content-center gap-2">
              <a class="my-auto" type="button"><img src="../demo/img/social-0.png" class="img-fluid" alt="..."></a>
              <a class="my-auto" type="button"><img src="../demo/img/social-1.png" class="img-fluid" alt="..."></a>
              <a class="my-auto" type="button"><img src="../demo/img/icon-logo.png" class="img-fluid" alt="..."></a>
              <a class="my-auto" type="button"><img src="../demo/img/social-2.png" class="img-fluid" alt="..."></a>
              <a class="my-auto" type="button"><img src="../demo/img/social-3.png" class="img-fluid" alt="..."></a>
            </div>
          </div>
        </section>

        <section class="section-3">
          <div class="row">
            <div class="col-lg-8">

              <div class="single-representative">

                <h3 class="title mb-5">Bài viết tiêu biểu</h3>

                <div class="list-item slider-representative">
                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              <div class="single-news">

                <h3 class="title mb-5">Bài viết mới nhất</h3>  

                <div class="list-item-news">
                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="../demo/img/image-93.png" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                          <h5 class="card-title">TƯNG BỪNG KHAI TRƯƠNG KIOSK TỰ PHỤC VỤ 24/7</h5>
                          <p class="card-text">Ngày 20/8 vừa qua, Công ty Cổ phần Miraway Giải pháp Công nghệ đã triển khai thành công Kiosk tự phục vụ 24/7 (Self – Service Kiosk) tại 30 cửa hàng lớn thuộc hệ thống Winmart+.</p>
                          <a href="#" class="read-more float-end">Xem thêm</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div class="col-lg-4">
                <div class="register mb-5">
                  <h3 class="text text-center">Đăng ký tài khoản viết bài</h3>
                  <form class="register-form">
                    <div class="mb-3">
                      <label for="exampleInputName" class="form-label">Họ và tên</label>
                      <input type="text" class="form-control" id="exampleInputName">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail" class="form-label">Email</label>
                      <input type="email" class="form-control" id="exampleInputEmail" aria-describedby="email">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Mật khẩu</label>
                      <input type="password" class="form-control" id="exampleInputPassword1">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Đăng ký</button>
                  </form>
                </div>

                <div class="read-more mb-5">
                  <h6><img src="../demo/img/icon-read.png" class="img-fluid" alt="..."> Xem thêm</h6>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                    <li class="list-group-item">Thông báo Hợp tác chiến lược giữa Miraway – Bắc Hải – Viettelconstruction</li>
                  </ul>
                </div>

                <div class="tags">
                  <h6><img src="../demo/img/tags.png" class="img-fluid" alt="..."> Tags</h6>
                  <a class="btn btn-outline-secondary" href="#" role="button">CDP</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">CETM</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">IDG</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">Miraway</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">Tài chính</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">Trải nghiệm khách hàng</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">Hội thảo</a>
                  <a class="btn btn-outline-secondary" href="#" role="button">Dữ liệu khách hàng</a>
                </div>
            </div>
          </div>
        </section>

        <section id="register" class="section-4 my-5">
          <h3 class="text-center">Đăng ký xem bài viết mới</h3>
          <div class="form-register">
            <form class="row g-2">
              <label for="staticEmail2">Email</label>
              <div class="col-7">
                <input type="text" readonly class="form-control" id="staticEmail2" value="email@example.com">
              </div>
              <div class="col-5">
                <button type="submit" class="btn btn-primary w-100">Đăng ký</button>
              </div>
            </form>
          </div>
        </section>
      </div>
    </main>

    <footer id="footer" class="pt-5 pb-3">
      <div class="container">
        <div class="row">
          <div class="img-logo mb-2">
            <img class="img-fluid" src="../demo/img/logoFooter.png">
          </div>
          <div class="col-lg-5 pb-5">
            <div class="logo">
              <p class="text text-white">CÔNG TY CỔ PHẦN MIRAWAY GIẢI PHÁP CÔNG NGHỆ</p>
              <p class="text-white"><img src="../demo/img/add.png" class="img-fluid" alt="..."> VP Tại Hà Nội: Tầng 4 - Tòa nhà GTC, Số 69, phố Tố Hữu, Vạn Phúc, Hà Đông, Hà Nội</p>
              <p class="text-white"><img src="../demo/img/add.png" class="img-fluid" alt="..."> VP Tại HCM: Số 52B, Nguyễn Bỉnh Khiêm, P. Đa Kao, Quận 1, TP.Hồ Chí Minh</p>
              <div class="contact">
                <p class="text-white"><img src="../demo/img/phone-call-1.png" class="img-fluid" alt="..."> Tel: 024 36 436 999</p>
                <p class="text-white"><img src="../demo/img/phone-call-2.png" class="img-fluid" alt="..."> Hotline tư vấn 24/7: 0981 350 960</p>
                <p class="text-white"><img src="../demo/img/phone-call-3.png" class="img-fluid" alt="..."> contact@miraway.vn</p>
              </div>
            </div>
          </div>
          <div class="col-lg-2">
            <ul class="menu">
              <li><a href="#">Giới thiệu Miraway</a></li>
              <li><a href="#">Cơ hội nghệ nghiệp</a></li>
              <li><a href="#">Lĩnh vực hoạt động</a></li>
              <li><a href="#">Tin tức & Hoạt động</a></li>
              <li><a href="#">Liên hệ</a></li>
            </ul>
          </div>
          <div class="col-lg-2">
            <ul class="menu">
              <li><a href="#">Chính sách bảo mật</a></li>
              <li><a href="#">Điều khoản sử dụng</a></li>
            </ul>
          </div>
          <div class="social col-lg-3">
            <h5>Mạng xã hội</h5>
            <div class="d-flex d-inline my-auto">
              <a href="#"><img src="../demo/img/social1.png" class="img-fluid" alt="..."></a>
              <a href="#"><img src="../demo/img/social2.png" class="img-fluid" alt="..."></a>
              <a href="#"><img src="../demo/img/social3.png" class="img-fluid" alt="..."></a>
              <a href="#"><img src="../demo/img/social4.png" class="img-fluid" alt="..."></a>
            </div>
          </div>

          <div class="footer-bottom">
            <a href="#" class="text-white">© Copyright – 2023 | MIRAWAY | All Rights Reserved</a>
          </div>
        </div>
      </div>
    </footer>

    <?php include 'footer.php'; ?>
  </body>
</html>